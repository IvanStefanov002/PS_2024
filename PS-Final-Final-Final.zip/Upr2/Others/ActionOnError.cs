﻿namespace Upr2.Others;

public delegate void ActionOnError(string errorMessage);