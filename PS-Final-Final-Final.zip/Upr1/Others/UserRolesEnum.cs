﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Upr1.Others;
public enum UserRolesEnum
{
    ANONYMOUS, ADMIN, INSPECTOR, PROFESSOR, STUDENT
}

