﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Upr6.Commands;

namespace Upr6.ViewModel
{
    public class MainWindowViewModel
    {
        public ObservableCollection<string> Users { get; set; } = new ObservableCollection<string>() { "gosho", "misho" };

        public AddUserCommand AddUserCommand { get; set; } = new AddUserCommand();
        public MainWindowViewModel()
        {
            
        }
    }
}
